import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// IMPORTACIONES NUESTRAS
import 'src/app.dart';

void main() {
  runApp(new MyApp());
}
