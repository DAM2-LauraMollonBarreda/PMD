package com.example.navegacion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
