package com.creatersolutions.firebase_app_dam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
